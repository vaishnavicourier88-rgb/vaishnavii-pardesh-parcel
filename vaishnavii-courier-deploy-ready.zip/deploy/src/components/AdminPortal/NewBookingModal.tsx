import React, { useState } from 'react';
import { 
  PackagePlus, 
  X, 
  User, 
  Phone, 
  MapPin, 
  Globe, 
  Scale, 
  FileText, 
  DollarSign, 
  Plane, 
  CheckCircle2, 
  AlertCircle,
  Truck,
  Building
} from 'lucide-react';
import { CountryRate, ShipmentData, StaffUser } from '../../types';
import { addOrUpdateShipment, generateNextAWB, getCountryRates } from '../../utils/storageManager';

interface NewBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: StaffUser;
  onBookingSuccess: (newShipment: ShipmentData) => void;
}

export const NewBookingModal: React.FC<NewBookingModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onBookingSuccess,
}) => {
  const countryRates = getCountryRates();

  // Form states
  const [senderName, setSenderName] = useState('');
  const [senderPhone, setSenderPhone] = useState('');
  const [senderCity, setSenderCity] = useState(currentUser.branchCity.split(' ')[0] || 'Mumbai');
  const [senderAddress, setSenderAddress] = useState('');
  
  const [receiverName, setReceiverName] = useState('');
  const [receiverPhone, setReceiverPhone] = useState('');
  const [receiverCountry, setReceiverCountry] = useState('United States (USA)');
  const [receiverCity, setReceiverCity] = useState('');
  const [receiverAddress, setReceiverAddress] = useState('');
  const [receiverPostalCode, setReceiverPostalCode] = useState('');

  const [packageType, setPackageType] = useState('Homemade Food & Sweets (Vacuum Sealed)');
  const [serviceType, setServiceType] = useState('International Priority Express');
  const [partnerNetwork, setPartnerNetwork] = useState<'FedEx' | 'DHL' | 'Aramex' | 'Vaishnavii Direct Express' | 'UPS'>('Vaishnavii Direct Express');
  
  const [weightKg, setWeightKg] = useState<number>(3.5);
  const [lengthCm, setLengthCm] = useState<number>(25);
  const [widthCm, setWidthCm] = useState<number>(20);
  const [heightCm, setHeightCm] = useState<number>(15);
  const [pieces, setPieces] = useState<number>(1);
  const [declaredValueInr, setDeclaredValueInr] = useState<number>(3500);

  const [customClientRatePerKg, setCustomClientRatePerKg] = useState<number | ''>('');
  const [paymentStatus, setPaymentStatus] = useState<'Paid' | 'Pending' | 'Credit'>('Paid');

  if (!isOpen) return null;

  // Selected country tariff
  const selectedCountry = countryRates.find((c) => c.name === receiverCountry) || countryRates[0];

  // Volumetric weight: (L * W * H) / 5000
  const volumetricWeightKg = Number(((lengthCm * widthCm * heightCm) / 5000).toFixed(2));
  const chargeableWeightKg = Math.max(weightKg, volumetricWeightKg);

  // Rates calculation
  const publicBaseRate = selectedCountry ? selectedCountry.baseRatePerKg : 650;
  const agentWholesaleRate = selectedCountry?.agentWholesaleRatePerKg || Math.round(publicBaseRate * 0.75);

  const clientPerKg = typeof customClientRatePerKg === 'number' && customClientRatePerKg > 0 
    ? customClientRatePerKg 
    : publicBaseRate;

  const totalClientBilling = Math.round(chargeableWeightKg * clientPerKg);
  const totalAgentWholesaleCost = Math.round(chargeableWeightKg * agentWholesaleRate);
  
  // Agent Profit / Commission
  const isAgent = currentUser.role === 'AGENT';
  const commissionPercentage = currentUser.commissionPercentage || 12;
  const agentCommission = isAgent 
    ? Math.round(totalClientBilling - totalAgentWholesaleCost) 
    : Math.round(totalClientBilling * (commissionPercentage / 100));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const awb = generateNextAWB();
    const currentDate = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    const currentTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    // Initial default checkpoints
    const initialCheckpoints = [
      {
        id: 'cp1',
        status: 'Shipment Booked & AWB Created',
        location: `${senderCity} Branch Hub, India`,
        timestamp: `${currentDate}, ${currentTime}`,
        description: `Shipment booked by ${currentUser.name} (${currentUser.branchName}). AWB barcode generated.`,
        completed: true,
        current: true,
      },
      {
        id: 'cp2',
        status: 'Security Packaging & Weight Verification',
        location: `${senderCity} Hub`,
        timestamp: 'Scheduled',
        description: 'Electronic tare weight verified & tamper-proof barcode strapped.',
        completed: false,
      },
      {
        id: 'cp3',
        status: 'Customs Clearance & Cargo Handover',
        location: 'International Air Cargo Gateway',
        timestamp: 'Pending',
        description: 'Export shipping bill passed and handed over to partner network.',
        completed: false,
      },
      {
        id: 'cp4',
        status: 'International Flight Departure',
        location: 'Air Transit Hub',
        timestamp: 'Pending',
        description: 'Loaded on scheduled overseas flight.',
        completed: false,
      },
      {
        id: 'cp5',
        status: 'Destination Customs & Doorstep Delivery',
        location: `${receiverCity || 'Destination'}, ${receiverCountry}`,
        timestamp: 'Pending',
        description: 'Out for final delivery to recipient.',
        completed: false,
      },
    ];

    const newShipment: ShipmentData = {
      trackingNumber: awb,
      senderName,
      senderPhone,
      senderCity,
      senderCountry: 'India (IN)',
      senderAddress,
      receiverName,
      receiverPhone,
      receiverCity: receiverCity || 'Destination City',
      receiverCountry,
      receiverAddress,
      receiverPostalCode,
      status: 'Booked',
      statusColor: 'bg-blue-500',
      serviceType,
      weightKg: chargeableWeightKg,
      chargeableWeightKg,
      lengthCm,
      widthCm,
      heightCm,
      pieces,
      declaredValueInr,
      expectedDelivery: 'In 3 - 5 Business Days',
      bookingDate: `${currentDate}, ${currentTime}`,
      lastUpdated: `${currentDate}, ${currentTime}`,
      partnerNetwork,
      originAirport: `${senderCity.toUpperCase().substring(0, 3)} - Air Cargo Gateway`,
      destinationAirport: `${receiverCountry.substring(0, 3).toUpperCase()} - International Gateway`,
      packageType,
      bookedBy: currentUser.name,
      agentName: currentUser.name,
      billingAmountInr: totalClientBilling,
      agentCommissionInr: agentCommission,
      paymentStatus,
      checkpoints: initialCheckpoints,
    };

    addOrUpdateShipment(newShipment);
    onBookingSuccess(newShipment);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden relative my-6 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white p-5 sm:p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center shadow-md">
              <PackagePlus className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-blue-300 font-bold">
                Internal Ops Desk
              </span>
              <h3 className="text-xl font-black tracking-tight text-white">
                New International Consignment Booking
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/80 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Booking Form */}
        <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6 max-h-[80vh] overflow-y-auto">
          
          {/* Staff Info Banner */}
          <div className="bg-blue-50 border border-blue-200 rounded-2xl p-3.5 flex flex-wrap items-center justify-between text-xs gap-2">
            <div className="flex items-center gap-2 text-blue-950 font-bold">
              <Building className="w-4 h-4 text-blue-600" />
              <span>Booking Branch: {currentUser.branchName} ({currentUser.branchCity})</span>
            </div>
            <div className="text-slate-600">
              Agent / Officer: <strong className="text-slate-900">{currentUser.name}</strong> ({currentUser.role})
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Sender (Shipper) Card */}
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                <User className="w-4 h-4 text-blue-600" />
                <h4 className="font-bold text-slate-900 text-sm uppercase tracking-wide">
                  1. Shipper / Sender (India Origin)
                </h4>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Sender Full Name *</label>
                <input
                  type="text"
                  required
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder="e.g. Ramesh Bhai Patel"
                  className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Phone / Mobile *</label>
                  <input
                    type="tel"
                    required
                    value={senderPhone}
                    onChange={(e) => setSenderPhone(e.target.value)}
                    placeholder="+91 98200 XXXXX"
                    className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Origin City *</label>
                  <input
                    type="text"
                    required
                    value={senderCity}
                    onChange={(e) => setSenderCity(e.target.value)}
                    placeholder="Mumbai / Delhi / Ahmedabad"
                    className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Street Address in India</label>
                <textarea
                  rows={2}
                  value={senderAddress}
                  onChange={(e) => setSenderAddress(e.target.value)}
                  placeholder="House/Shop no., Building, Landmark..."
                  className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            {/* Receiver (Consignee) Card */}
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                <Globe className="w-4 h-4 text-blue-600" />
                <h4 className="font-bold text-slate-900 text-sm uppercase tracking-wide">
                  2. Consignee / Receiver (Overseas)
                </h4>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Destination Country *</label>
                <select
                  value={receiverCountry}
                  onChange={(e) => setReceiverCountry(e.target.value)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  {countryRates.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.flag} {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Receiver Full Name *</label>
                <input
                  type="text"
                  required
                  value={receiverName}
                  onChange={(e) => setReceiverName(e.target.value)}
                  placeholder="e.g. John Doe / Amit Sharma"
                  className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Destination City *</label>
                  <input
                    type="text"
                    required
                    value={receiverCity}
                    onChange={(e) => setReceiverCity(e.target.value)}
                    placeholder="e.g. Dallas / London / Toronto"
                    className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Postal / ZIP Code *</label>
                  <input
                    type="text"
                    required
                    value={receiverPostalCode}
                    onChange={(e) => setReceiverPostalCode(e.target.value)}
                    placeholder="e.g. 75201 / M5V 2T6"
                    className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Receiver Overseas Address *</label>
                <input
                  type="text"
                  required
                  value={receiverAddress}
                  onChange={(e) => setReceiverAddress(e.target.value)}
                  placeholder="Apt, Suite, Street name"
                  className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

          </div>

          {/* Package Specs, Weight & Network Routing */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
              <Scale className="w-4 h-4 text-blue-600" />
              <h4 className="font-bold text-slate-900 text-sm uppercase tracking-wide">
                3. Parcel Dimensions, Weight & Customs Category
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Category / Goods</label>
                <select
                  value={packageType}
                  onChange={(e) => setPackageType(e.target.value)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  <option value="Homemade Food & Sweets (Vacuum Sealed)">Homemade Food & Sweets</option>
                  <option value="Prescription Medicines with Doctor Slip">Prescription Medicines</option>
                  <option value="Student Baggage, Books & Personal Clothes">Student Baggage & Clothes</option>
                  <option value="Urgent Educational & Legal Documents">Urgent Documents / WES</option>
                  <option value="Commercial Export Samples & Merchandise">Commercial Cargo / B2B</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Network Carrier Route</label>
                <select
                  value={partnerNetwork}
                  onChange={(e) => setPartnerNetwork(e.target.value as any)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  <option value="Vaishnavii Direct Express">Vaishnavii Direct Express (Best Margin)</option>
                  <option value="DHL">DHL Express Worldwide</option>
                  <option value="FedEx">FedEx International Priority</option>
                  <option value="Aramex">Aramex Middle East / Gulf Express</option>
                  <option value="UPS">UPS Worldwide Saver</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Payment Status</label>
                <select
                  value={paymentStatus}
                  onChange={(e) => setPaymentStatus(e.target.value as any)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  <option value="Paid">✅ Paid in Full (Cash/UPI/Bank)</option>
                  <option value="Pending">⏳ Pending at Pickup</option>
                  <option value="Credit">💳 Monthly B2B Account Credit</option>
                </select>
              </div>
            </div>

            {/* Weights & Dimensions */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Actual Weight (KG)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  required
                  value={weightKg}
                  onChange={(e) => setWeightKg(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-blue-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Length (cm)</label>
                <input
                  type="number"
                  min="1"
                  value={lengthCm}
                  onChange={(e) => setLengthCm(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Width (cm)</label>
                <input
                  type="number"
                  min="1"
                  value={widthCm}
                  onChange={(e) => setWidthCm(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Height (cm)</label>
                <input
                  type="number"
                  min="1"
                  value={heightCm}
                  onChange={(e) => setHeightCm(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Chargeable (KG)</label>
                <div className="w-full px-3 py-2 bg-blue-100/70 border border-blue-300 rounded-xl text-xs font-black text-blue-900">
                  {chargeableWeightKg} KG
                </div>
              </div>
            </div>
          </div>

          {/* Pricing & Agent Wholesale / Profit Breakdown */}
          <div className="bg-gradient-to-br from-slate-900 to-blue-950 text-white p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="font-bold text-sm text-blue-300 uppercase tracking-wide">
                4. Billing & Tariff Breakdown (Hidden from Public Client)
              </span>
              <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full font-mono font-bold">
                Wholesale Margin Active
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
              <div className="p-3 bg-white/10 rounded-xl">
                <span className="text-[11px] text-slate-300 block">Agent Wholesale Cost/kg</span>
                <span className="text-base font-bold font-mono text-white">₹{agentWholesaleRate} / kg</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Total Cost: ₹{totalAgentWholesaleCost}</span>
              </div>

              <div className="p-3 bg-white/10 rounded-xl">
                <span className="text-[11px] text-slate-300 block">Client Selling Rate/kg</span>
                <span className="text-base font-bold font-mono text-emerald-400">₹{clientPerKg} / kg</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Standard: ₹{publicBaseRate}/kg</span>
              </div>

              <div className="p-3 bg-white/10 rounded-xl">
                <span className="text-[11px] text-slate-300 block">Total Client Invoice Amount</span>
                <span className="text-lg font-black font-mono text-white">₹{totalClientBilling.toLocaleString('en-IN')}</span>
                <span className="text-[10px] text-emerald-300 block mt-0.5">Incl. GST & Clearance</span>
              </div>

              <div className="p-3 bg-emerald-500/20 border border-emerald-500/30 rounded-xl">
                <span className="text-[11px] text-emerald-300 block font-bold">Agent Commission / Margin</span>
                <span className="text-lg font-black font-mono text-emerald-400">+ ₹{agentCommission.toLocaleString('en-IN')}</span>
                <span className="text-[10px] text-slate-300 block mt-0.5">Your Branch Net Profit</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 transition cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-black shadow-lg transition flex items-center gap-2 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm Booking & Generate AWB</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
