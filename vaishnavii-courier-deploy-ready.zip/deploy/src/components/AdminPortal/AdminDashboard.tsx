import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Package, 
  DollarSign, 
  TrendingUp, 
  Users, 
  Search, 
  Plus, 
  Printer, 
  Edit3, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  Plane, 
  FileText, 
  LogOut, 
  Download, 
  Upload, 
  RefreshCw, 
  MapPin, 
  Phone, 
  Globe, 
  Filter, 
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Server,
  Building,
  UserCheck,
  Calendar
} from 'lucide-react';
import { CountryRate, PickupBookingRequest, ShipmentData, StaffUser, UserRole } from '../../types';
import { 
  addOrUpdateShipment, 
  getAuthSession, 
  getCountryRates, 
  getPickupLeads, 
  getShipments, 
  getStaffUsers, 
  saveCountryRates, 
  savePickupLeads, 
  saveShipments, 
  saveStaffUsers, 
  setAuthSession 
} from '../../utils/storageManager';
import { NewBookingModal } from './NewBookingModal';
import { AWBLabelPrintModal } from './AWBLabelPrintModal';

interface AdminDashboardProps {
  currentUser: StaffUser;
  onLogout: () => void;
  onNavigateToPublicWebsite: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  onLogout,
  onNavigateToPublicWebsite,
}) => {
  const [activeTab, setActiveTab] = useState<'bookings' | 'rates' | 'pickups' | 'agents' | 'hostinger'>('bookings');
  
  // Data states
  const [shipments, setShipments] = useState<Record<string, ShipmentData>>({});
  const [countryRates, setCountryRates] = useState<CountryRate[]>([]);
  const [pickupLeads, setPickupLeads] = useState<PickupBookingRequest[]>([]);
  const [staffUsers, setStaffUsers] = useState<(StaffUser & { passwordHash: string })[]>([]);

  // Modals
  const [isNewBookingOpen, setIsNewBookingOpen] = useState(false);
  const [selectedAWBForPrint, setSelectedAWBForPrint] = useState<ShipmentData | null>(null);

  // Search & Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Rate Matrix Editing state
  const [editingRateCountryId, setEditingRateCountryId] = useState<string | null>(null);
  const [rateEditBase, setRateEditBase] = useState<number>(0);
  const [rateEditWholesale, setRateEditWholesale] = useState<number>(0);
  const [rateEditDoc, setRateEditDoc] = useState<number>(0);
  const [rateEditMed, setRateEditMed] = useState<number>(0);
  const [rateEditFuel, setRateEditFuel] = useState<number>(0);

  // New Country Modal state
  const [showAddCountryModal, setShowAddCountryModal] = useState(false);
  const [newCountryName, setNewCountryName] = useState('');
  const [newCountryCode, setNewCountryCode] = useState('');
  const [newCountryFlag, setNewCountryFlag] = useState('🌐');
  const [newCountryRegion, setNewCountryRegion] = useState('Europe');
  const [newCountryBaseRate, setNewCountryBaseRate] = useState(600);
  const [newCountryWholesaleRate, setNewCountryWholesaleRate] = useState(450);
  const [newCountryDocRate, setNewCountryDocRate] = useState(1700);

  // Status Updater Modal
  const [updatingShipmentAWB, setUpdatingShipmentAWB] = useState<string | null>(null);
  const [newStatus, setNewStatus] = useState<ShipmentData['status']>('In Transit');
  const [newCheckpointLocation, setNewCheckpointLocation] = useState('');
  const [newCheckpointDesc, setNewCheckpointDesc] = useState('');

  // Load initial data
  const loadAllData = () => {
    setShipments(getShipments());
    setCountryRates(getCountryRates());
    setPickupLeads(getPickupLeads());
    setStaffUsers(getStaffUsers());
  };

  useEffect(() => {
    loadAllData();
  }, []);

  const shipmentList: ShipmentData[] = Object.values(shipments);

  // Filtered shipments
  const filteredShipments = shipmentList.filter((s) => {
    const matchesSearch = 
      s.trackingNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.receiverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.senderName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.receiverCountry.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'ALL' || s.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Calculate Metrics
  const totalConsignments = shipmentList.length;
  const inTransitCount = shipmentList.filter((s) => s.status === 'In Transit' || s.status === 'Customs Clearance' || s.status === 'Out for Delivery').length;
  const deliveredCount = shipmentList.filter((s) => s.status === 'Delivered').length;
  const totalRevenue: number = shipmentList.reduce((acc: number, s: ShipmentData) => acc + (s.billingAmountInr || (s.weightKg * 2500)), 0);
  const totalCommission: number = shipmentList.reduce((acc: number, s: ShipmentData) => acc + (s.agentCommissionInr || (s.weightKg * 350)), 0);
  const pendingPickups = pickupLeads.filter((p) => p.status === 'Pending').length;

  // Handle Rate Matrix Save
  const startEditingRate = (country: CountryRate) => {
    setEditingRateCountryId(country.id);
    setRateEditBase(country.baseRatePerKg);
    setRateEditWholesale(country.agentWholesaleRatePerKg || Math.round(country.baseRatePerKg * 0.75));
    setRateEditDoc(country.docRate);
    setRateEditMed(country.medicineSurcharge || 500);
    setRateEditFuel(country.fuelSurchargePercent || 12);
  };

  const saveEditedRate = (countryId: string) => {
    const updated = countryRates.map((c) => {
      if (c.id === countryId) {
        return {
          ...c,
          baseRatePerKg: rateEditBase,
          agentWholesaleRatePerKg: rateEditWholesale,
          docRate: rateEditDoc,
          medicineSurcharge: rateEditMed,
          fuelSurchargePercent: rateEditFuel,
        };
      }
      return c;
    });
    setCountryRates(updated);
    saveCountryRates(updated);
    setEditingRateCountryId(null);
  };

  // Add New Country Tariff
  const handleAddNewCountry = (e: React.FormEvent) => {
    e.preventDefault();
    const newCountry: CountryRate = {
      id: newCountryName.toLowerCase().replace(/\s+/g, '-'),
      name: newCountryName,
      code: newCountryCode.toUpperCase(),
      flag: newCountryFlag || '🌐',
      region: newCountryRegion,
      expressDays: '3 - 6 Days',
      economyDays: '7 - 10 Days',
      baseRatePerKg: newCountryBaseRate,
      agentWholesaleRatePerKg: newCountryWholesaleRate,
      docRate: newCountryDocRate,
      medicineSurcharge: 500,
      fuelSurchargePercent: 12,
      medicineAllowed: true,
      foodAllowed: true,
      popular: false,
    };

    const updated = [...countryRates, newCountry];
    setCountryRates(updated);
    saveCountryRates(updated);
    setShowAddCountryModal(false);
    setNewCountryName('');
    setNewCountryCode('');
  };

  // Handle Shipment Status Update
  const handleUpdateStatusSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!updatingShipmentAWB) return;

    const current = shipments[updatingShipmentAWB];
    if (!current) return;

    const currentDate = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    const currentTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    let statusColor = 'bg-blue-500';
    if (newStatus === 'Delivered') statusColor = 'bg-emerald-500';
    else if (newStatus === 'Out for Delivery') statusColor = 'bg-amber-500';
    else if (newStatus === 'Customs Clearance') statusColor = 'bg-purple-500';
    else if (newStatus === 'On Hold') statusColor = 'bg-red-500';

    const newCheckpoint = {
      id: `cp_${Date.now()}`,
      status: newStatus === 'Delivered' ? 'Delivered to Recipient' : (newCheckpointDesc || `Status updated to ${newStatus}`),
      location: newCheckpointLocation || `${current.receiverCity}, ${current.receiverCountry}`,
      timestamp: `${currentDate}, ${currentTime}`,
      description: newCheckpointDesc || `Consignment checkpoint recorded by ${currentUser.name}.`,
      completed: true,
      current: true,
    };

    // Mark previous current as completed
    const updatedCheckpoints = current.checkpoints.map((cp) => ({ ...cp, current: false }));
    updatedCheckpoints.push(newCheckpoint);

    const updatedShipment: ShipmentData = {
      ...current,
      status: newStatus,
      statusColor,
      lastUpdated: `${currentDate}, ${currentTime}`,
      checkpoints: updatedCheckpoints,
    };

    addOrUpdateShipment(updatedShipment);
    loadAllData();
    setUpdatingShipmentAWB(null);
    setNewCheckpointDesc('');
    setNewCheckpointLocation('');
  };

  // Assign Pickup Lead to Agent
  const handleAssignPickup = (leadId: string, agentName: string) => {
    const updated = pickupLeads.map((p) => {
      if (p.id === leadId) {
        return {
          ...p,
          status: 'Assigned' as const,
          assignedAgent: agentName,
        };
      }
      return p;
    });
    setPickupLeads(updated);
    savePickupLeads(updated);
  };

  // Convert Pickup Lead to Booking
  const handleConvertLeadToBooking = (lead: PickupBookingRequest) => {
    setIsNewBookingOpen(true);
  };

  // Export Data to JSON
  const handleExportData = () => {
    const data = {
      exportedAt: new Date().toISOString(),
      shipments: getShipments(),
      countryRates: getCountryRates(),
      pickupLeads: getPickupLeads(),
      staffUsers: getStaffUsers(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vaishnavii_courier_backup_${new Date().toISOString().substring(0, 10)}.json`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      
      {/* Top Staff Navigation Header */}
      <header className="bg-slate-900 text-white sticky top-0 z-30 shadow-lg border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Logo & Portal Title */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-lg tracking-tight text-white">
                    VAISHNAVII
                  </span>
                  <span className="text-[10px] uppercase font-mono font-bold bg-blue-600 text-white px-2 py-0.5 rounded-full">
                    {currentUser.role === 'ADMIN' ? '👑 Master Admin' : currentUser.role === 'SUB_ADMIN' ? '⚡ Sub-Admin Ops' : '🏢 Agent Desk'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  {currentUser.branchName} • {currentUser.branchCity}
                </p>
              </div>
            </div>

            {/* User Profile & Action Buttons */}
            <div className="flex items-center gap-3">
              <button
                onClick={onNavigateToPublicWebsite}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold transition border border-slate-700 cursor-pointer"
                title="View what public clients see"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>View Public Site</span>
              </button>

              <div className="hidden md:flex flex-col text-right">
                <span className="text-xs font-bold text-white">{currentUser.name}</span>
                <span className="text-[10px] text-blue-400 font-mono">Commission: {currentUser.commissionPercentage}%</span>
              </div>

              <button
                onClick={onLogout}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600/20 hover:bg-red-600 text-red-300 hover:text-white rounded-lg text-xs font-bold transition border border-red-500/30 cursor-pointer"
                title="Log Out of Admin Portal"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>

          </div>
        </div>

        {/* Tab Navigation Navigation Strip */}
        <div className="bg-slate-950/80 border-t border-slate-800/80 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto flex items-center gap-2 overflow-x-auto py-2">
            <button
              onClick={() => setActiveTab('bookings')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                activeTab === 'bookings'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>Consignments & AWB Manager ({shipmentList.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('rates')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                activeTab === 'rates'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <DollarSign className="w-4 h-4" />
              <span>Confidential Rate List & Wholesale Tariff ({countryRates.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('pickups')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                activeTab === 'pickups'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>Customer Pickup Leads ({pickupLeads.length})</span>
              {pendingPickups > 0 && (
                <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
              )}
            </button>

            {(currentUser.role === 'ADMIN' || currentUser.role === 'SUB_ADMIN') && (
              <button
                onClick={() => setActiveTab('agents')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                  activeTab === 'agents'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Agent & Sub-Admin Management ({staffUsers.length})</span>
              </button>
            )}

            <button
              onClick={() => setActiveTab('hostinger')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                activeTab === 'hostinger'
                  ? 'bg-emerald-700 text-white shadow-md'
                  : 'text-emerald-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Server className="w-4 h-4" />
              <span>Hostinger Deployment & Backup</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 space-y-6">
        
        {/* Metric Cards Top Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                Total Shipments
              </span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">
                {totalConsignments}
              </span>
              <span className="text-[10px] text-emerald-600 font-semibold">
                {deliveredCount} Delivered Intact
              </span>
            </div>
            <div className="w-11 h-11 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                Active In-Transit
              </span>
              <span className="text-2xl font-black text-blue-600 mt-1 block">
                {inTransitCount}
              </span>
              <span className="text-[10px] text-slate-500">
                Customs / In Flight
              </span>
            </div>
            <div className="w-11 h-11 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Plane className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                Total Billing Volume
              </span>
              <span className="text-2xl font-black text-slate-900 mt-1 block font-mono">
                ₹{(totalRevenue / 1000).toFixed(1)}k
              </span>
              <span className="text-[10px] text-emerald-600 font-bold">
                Margin: ₹{(totalCommission / 1000).toFixed(1)}k
              </span>
            </div>
            <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                Doorstep Pickups
              </span>
              <span className="text-2xl font-black text-amber-600 mt-1 block">
                {pendingPickups}
              </span>
              <span className="text-[10px] text-slate-500">
                Online customer requests
              </span>
            </div>
            <div className="w-11 h-11 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* TAB 1: Consignments & AWB Live Manager */}
        {activeTab === 'bookings' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            
            {/* Table Control Bar */}
            <div className="p-5 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex flex-col sm:flex-row sm:items-center gap-3 flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search AWB, Shipper, Consignee, Country..."
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  <option value="ALL">All Statuses ({shipmentList.length})</option>
                  <option value="Booked">Booked</option>
                  <option value="In Transit">In Transit</option>
                  <option value="Customs Clearance">Customs Clearance</option>
                  <option value="Out for Delivery">Out for Delivery</option>
                  <option value="Delivered">Delivered</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsNewBookingOpen(true)}
                  className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black shadow-md transition cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>New Consignment Booking</span>
                </button>
              </div>
            </div>

            {/* Consignment Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="p-4">Airway Bill (AWB)</th>
                    <th className="p-4">Shipper (From)</th>
                    <th className="p-4">Consignee (To)</th>
                    <th className="p-4">Weight / Network</th>
                    <th className="p-4">Live Status</th>
                    <th className="p-4">Billing & Commission</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-800">
                  {filteredShipments.map((s) => (
                    <tr key={s.trackingNumber} className="hover:bg-slate-50/80 transition">
                      <td className="p-4 font-mono font-bold text-blue-900">
                        <div className="flex items-center gap-1.5">
                          <Plane className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                          <span>{s.trackingNumber}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-sans font-normal mt-0.5">
                          {s.bookingDate}
                        </div>
                      </td>

                      <td className="p-4">
                        <div className="font-bold text-slate-900">{s.senderName}</div>
                        <div className="text-slate-500 text-[11px]">{s.senderCity}, India</div>
                      </td>

                      <td className="p-4">
                        <div className="font-bold text-slate-900">{s.receiverName}</div>
                        <div className="text-slate-600 text-[11px]">
                          {s.receiverCity}, {s.receiverCountry}
                        </div>
                      </td>

                      <td className="p-4">
                        <div className="font-bold text-slate-900">{s.weightKg} KG</div>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 bg-slate-100 rounded border border-slate-200 text-slate-600">
                          {s.partnerNetwork}
                        </span>
                      </td>

                      <td className="p-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold text-white shadow-2xs ${
                            s.status === 'Delivered'
                              ? 'bg-emerald-600'
                              : s.status === 'Out for Delivery'
                              ? 'bg-amber-600'
                              : s.status === 'Customs Clearance'
                              ? 'bg-purple-600'
                              : 'bg-blue-600'
                          }`}
                        >
                          {s.status}
                        </span>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          {s.checkpoints[s.checkpoints.length - 1]?.location.split(',')[0]}
                        </div>
                      </td>

                      <td className="p-4">
                        <div className="font-bold text-slate-900 font-mono">
                          ₹{(s.billingAmountInr || (s.weightKg * 2500)).toLocaleString('en-IN')}
                        </div>
                        <div className="text-[10px] text-emerald-600 font-semibold">
                          Comm: ₹{(s.agentCommissionInr || (s.weightKg * 350)).toLocaleString('en-IN')}
                        </div>
                      </td>

                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setSelectedAWBForPrint(s)}
                            className="p-1.5 bg-slate-100 hover:bg-blue-50 text-slate-600 hover:text-blue-700 rounded-lg border border-slate-200 transition cursor-pointer"
                            title="Print AWB Shipping Label & Barcode"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => {
                              setUpdatingShipmentAWB(s.trackingNumber);
                              setNewStatus(s.status);
                            }}
                            className="p-1.5 bg-slate-100 hover:bg-emerald-50 text-slate-600 hover:text-emerald-700 rounded-lg border border-slate-200 transition cursor-pointer"
                            title="Update Tracking Checkpoints & Status"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* TAB 2: Confidential Wholesale Rate List & Country Tariffs Matrix */}
        {activeTab === 'rates' && (
          <div className="space-y-6">
            
            {/* Info Banner */}
            <div className="bg-gradient-to-r from-slate-900 to-blue-950 text-white p-5 sm:p-6 rounded-3xl border border-slate-800 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-[10px] font-mono font-bold uppercase mb-2">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Confidential Agent Wholesale Tariff Matrix</span>
                </div>
                <h3 className="text-xl font-black text-white">
                  Country Rates & Profit Margins Manager
                </h3>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                  These wholesale costs and agent commissions are strictly protected and NEVER visible to clients on the public website. Edit base tariffs per kg below.
                </p>
              </div>

              {(currentUser.role === 'ADMIN' || currentUser.role === 'SUB_ADMIN') && (
                <button
                  onClick={() => setShowAddCountryModal(true)}
                  className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-black shadow-md transition cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Country Tariff</span>
                </button>
              )}
            </div>

            {/* Rate Matrix Table */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="p-4">Destination Country</th>
                      <th className="p-4">Public Rate/kg</th>
                      <th className="p-4 bg-blue-50/60 text-blue-900">Agent Wholesale Cost/kg</th>
                      <th className="p-4">Branch Profit/kg</th>
                      <th className="p-4">Doc Express Rate</th>
                      <th className="p-4">Medicine Surcharge</th>
                      <th className="p-4">Fuel Surch. %</th>
                      <th className="p-4 text-right">Edit Rate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-slate-800">
                    {countryRates.map((country) => {
                      const isEditing = editingRateCountryId === country.id;
                      const wholesale = country.agentWholesaleRatePerKg || Math.round(country.baseRatePerKg * 0.75);
                      const profitPerKg = country.baseRatePerKg - wholesale;

                      return (
                        <tr key={country.id} className="hover:bg-slate-50/80 transition">
                          <td className="p-4 font-bold text-slate-900">
                            <div className="flex items-center gap-2">
                              <span className="text-base">{country.flag}</span>
                              <div>
                                <span>{country.name}</span>
                                <span className="text-[10px] text-slate-400 block font-mono">{country.region}</span>
                              </div>
                            </div>
                          </td>

                          {/* Public Base Rate */}
                          <td className="p-4 font-mono font-bold text-slate-900">
                            {isEditing ? (
                              <input
                                type="number"
                                value={rateEditBase}
                                onChange={(e) => setRateEditBase(Number(e.target.value))}
                                className="w-20 px-2 py-1 bg-white border border-blue-400 rounded-md text-xs font-bold"
                              />
                            ) : (
                              <span>₹{country.baseRatePerKg} / kg</span>
                            )}
                          </td>

                          {/* Agent Wholesale Cost */}
                          <td className="p-4 font-mono font-bold text-blue-900 bg-blue-50/30">
                            {isEditing ? (
                              <input
                                type="number"
                                value={rateEditWholesale}
                                onChange={(e) => setRateEditWholesale(Number(e.target.value))}
                                className="w-20 px-2 py-1 bg-white border border-blue-400 rounded-md text-xs font-bold"
                              />
                            ) : (
                              <span className="text-blue-700">₹{wholesale} / kg</span>
                            )}
                          </td>

                          {/* Net Profit Margin / kg */}
                          <td className="p-4 font-mono font-bold text-emerald-600">
                            +₹{profitPerKg} / kg ({Math.round((profitPerKg / country.baseRatePerKg) * 100)}%)
                          </td>

                          {/* Document Rate */}
                          <td className="p-4 font-mono text-slate-700">
                            {isEditing ? (
                              <input
                                type="number"
                                value={rateEditDoc}
                                onChange={(e) => setRateEditDoc(Number(e.target.value))}
                                className="w-20 px-2 py-1 bg-white border border-blue-400 rounded-md text-xs"
                              />
                            ) : (
                              <span>₹{country.docRate}</span>
                            )}
                          </td>

                          {/* Medicine Surcharge */}
                          <td className="p-4 font-mono text-slate-700">
                            {isEditing ? (
                              <input
                                type="number"
                                value={rateEditMed}
                                onChange={(e) => setRateEditMed(Number(e.target.value))}
                                className="w-20 px-2 py-1 bg-white border border-blue-400 rounded-md text-xs"
                              />
                            ) : (
                              <span>₹{country.medicineSurcharge || 500}</span>
                            )}
                          </td>

                          {/* Fuel Surcharge % */}
                          <td className="p-4 font-mono text-slate-700">
                            {isEditing ? (
                              <input
                                type="number"
                                value={rateEditFuel}
                                onChange={(e) => setRateEditFuel(Number(e.target.value))}
                                className="w-16 px-2 py-1 bg-white border border-blue-400 rounded-md text-xs"
                              />
                            ) : (
                              <span>{country.fuelSurchargePercent || 12}%</span>
                            )}
                          </td>

                          {/* Action */}
                          <td className="p-4 text-right">
                            {isEditing ? (
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => saveEditedRate(country.id)}
                                  className="px-3 py-1 bg-emerald-600 text-white rounded-lg font-bold text-[11px] hover:bg-emerald-700 cursor-pointer shadow-xs"
                                >
                                  Save
                                </button>
                                <button
                                  onClick={() => setEditingRateCountryId(null)}
                                  className="px-2 py-1 bg-slate-200 text-slate-700 rounded-lg text-[11px] hover:bg-slate-300 cursor-pointer"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => startEditingRate(country)}
                                className="px-3 py-1 bg-slate-100 hover:bg-blue-50 text-blue-700 font-bold rounded-lg border border-slate-200 text-[11px] transition cursor-pointer"
                              >
                                Edit Tariff
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* TAB 3: Customer Pickup Leads Portal */}
        {activeTab === 'pickups' && (
          <div className="space-y-6">
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="p-5 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    Incoming Customer Doorstep Pickup Leads
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Leads submitted by NRI families and clients via website booking modal.
                  </p>
                </div>

                <span className="px-3 py-1 bg-blue-50 text-blue-800 rounded-full font-bold text-xs border border-blue-200">
                  {pickupLeads.length} Total Leads
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="p-4">Customer Details</th>
                      <th className="p-4">Pickup Address & City</th>
                      <th className="p-4">Destination & Category</th>
                      <th className="p-4">Scheduled Slot</th>
                      <th className="p-4">Status & Agent</th>
                      <th className="p-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-slate-800">
                    {pickupLeads.map((lead, idx) => (
                      <tr key={lead.id || idx} className="hover:bg-slate-50/80 transition">
                        <td className="p-4">
                          <div className="font-bold text-slate-900">{lead.fullName}</div>
                          <div className="text-slate-600 font-mono text-[11px] mt-0.5 flex items-center gap-1">
                            <Phone className="w-3 h-3 text-emerald-600" />
                            <a href={`tel:${lead.phone}`} className="hover:underline">{lead.phone}</a>
                          </div>
                        </td>

                        <td className="p-4 max-w-xs">
                          <div className="text-slate-900 font-medium">{lead.pickupAddress}</div>
                          <div className="text-[11px] text-slate-500 font-bold mt-0.5">
                            {lead.pickupCity} - {lead.pickupPincode}
                          </div>
                        </td>

                        <td className="p-4">
                          <div className="font-bold text-blue-900">{lead.destinationCountry}</div>
                          <div className="text-slate-600 text-[11px]">{lead.parcelType.toUpperCase()} (~{lead.approxWeightKg} KG)</div>
                        </td>

                        <td className="p-4 font-mono">
                          <div className="font-bold text-slate-900">{lead.pickupDate}</div>
                          <div className="text-[10px] text-slate-500 font-sans">{lead.pickupTimeSlot}</div>
                        </td>

                        <td className="p-4">
                          <span
                            className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold ${
                              lead.status === 'Assigned'
                                ? 'bg-blue-100 text-blue-800'
                                : lead.status === 'Picked Up'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {lead.status || 'Pending'}
                          </span>
                          {lead.assignedAgent && (
                            <div className="text-[10px] text-slate-500 mt-1 font-semibold">
                              Agent: {lead.assignedAgent.split(' ')[0]}
                            </div>
                          )}
                        </td>

                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            {lead.status !== 'Assigned' && (
                              <button
                                onClick={() => handleAssignPickup(lead.id || `lead_${idx}`, currentUser.name)}
                                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-[11px] transition cursor-pointer"
                              >
                                Accept Lead
                              </button>
                            )}

                            <button
                              onClick={() => handleConvertLeadToBooking(lead)}
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] transition cursor-pointer"
                            >
                              Book AWB
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: Agent & Sub-Admin Staff Management */}
        {activeTab === 'agents' && (
          <div className="space-y-6">
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="p-5 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    Authorized Staff & Regional Franchise Agents
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Manage role permissions, login credentials, and branch commission percentages.
                  </p>
                </div>

                <span className="px-3 py-1 bg-purple-50 text-purple-800 rounded-full font-bold text-xs border border-purple-200">
                  {staffUsers.length} Active Staff Accounts
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="p-4">User & Role</th>
                      <th className="p-4">Username & Login</th>
                      <th className="p-4">Branch Office</th>
                      <th className="p-4">Contact Phone</th>
                      <th className="p-4">Commission %</th>
                      <th className="p-4">Account Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-slate-800">
                    {staffUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50/80 transition">
                        <td className="p-4">
                          <div className="font-bold text-slate-900">{u.name}</div>
                          <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-md mt-1 ${
                            u.role === 'ADMIN' ? 'bg-amber-100 text-amber-900 font-mono' : u.role === 'SUB_ADMIN' ? 'bg-blue-100 text-blue-900' : 'bg-slate-100 text-slate-800'
                          }`}>
                            {u.role}
                          </span>
                        </td>

                        <td className="p-4 font-mono">
                          <div className="font-bold text-blue-900">@{u.username}</div>
                          <div className="text-[10px] text-slate-400">Pass: {u.passwordHash}</div>
                        </td>

                        <td className="p-4">
                          <div className="font-bold text-slate-900">{u.branchName}</div>
                          <div className="text-slate-500 text-[11px]">{u.branchCity}</div>
                        </td>

                        <td className="p-4 font-mono text-slate-700">{u.phone}</td>

                        <td className="p-4 font-mono font-bold text-emerald-600">
                          {u.commissionPercentage}%
                        </td>

                        <td className="p-4">
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-bold text-xs">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Active</span>
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: Hostinger Deployment & Data Backup Guide */}
        {activeTab === 'hostinger' && (
          <div className="space-y-6">
            
            {/* Hostinger Guide Card */}
            <div className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-xl space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500 flex items-center justify-center text-slate-950 font-black shadow-lg">
                  <Server className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold">
                    Production Web Hosting Ready
                  </span>
                  <h3 className="text-2xl font-black text-white">
                    How to Upload & Run on Hostinger (Complete Guide)
                  </h3>
                </div>
              </div>

              <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                Your application has been built in high-performance pure Vite & React with client-side RBAC data synchronization. You can deploy it to <strong>Hostinger Web Hosting, cPanel, or VPS</strong> within 2 minutes!
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 bg-white/10 rounded-2xl border border-white/10 space-y-2">
                  <div className="font-bold text-emerald-400 text-sm">Step 1: Export Build</div>
                  <p className="text-slate-300 leading-relaxed">
                    Download the project files or ZIP from the top menu, then in your terminal run: <br />
                    <code className="bg-black/50 px-2 py-1 rounded text-emerald-300 font-mono inline-block mt-1">npm run build</code>
                  </p>
                </div>

                <div className="p-4 bg-white/10 rounded-2xl border border-white/10 space-y-2">
                  <div className="font-bold text-emerald-400 text-sm">Step 2: Upload to Hostinger</div>
                  <p className="text-slate-300 leading-relaxed">
                    Log in to Hostinger hPanel ➔ <strong>File Manager</strong> ➔ open the <code className="bg-black/50 px-1 py-0.5 rounded text-amber-300 font-mono">public_html</code> folder ➔ upload all files inside the <code className="bg-black/50 px-1 py-0.5 rounded text-amber-300 font-mono">dist/</code> directory.
                  </p>
                </div>

                <div className="p-4 bg-white/10 rounded-2xl border border-white/10 space-y-2">
                  <div className="font-bold text-emerald-400 text-sm">Step 3: Live Worldwide</div>
                  <p className="text-slate-300 leading-relaxed">
                    Your website will be immediately live on your domain (e.g. <code>vaishnaviicourier.com</code>). Rates, bookings, and tracking work seamlessly!
                  </p>
                </div>
              </div>

              {/* Data Export & Backup Action */}
              <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <div className="font-bold text-white text-sm">Local Storage & Tariff Backup</div>
                  <div className="text-xs text-slate-400">Download all your custom rate changes, bookings, and users as JSON.</div>
                </div>

                <button
                  onClick={handleExportData}
                  className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black rounded-xl text-xs shadow-lg transition cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Complete Backup (.JSON)</span>
                </button>
              </div>
            </div>

          </div>
        )}

      </main>

      {/* Booking Modal */}
      <NewBookingModal
        isOpen={isNewBookingOpen}
        onClose={() => setIsNewBookingOpen(false)}
        currentUser={currentUser}
        onBookingSuccess={(newShipment) => {
          loadAllData();
          setSelectedAWBForPrint(newShipment);
        }}
      />

      {/* AWB Printable Label Modal */}
      <AWBLabelPrintModal
        shipment={selectedAWBForPrint}
        onClose={() => setSelectedAWBForPrint(null)}
      />

      {/* Status & Checkpoint Updater Modal */}
      {updatingShipmentAWB && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <h4 className="font-black text-slate-900 text-base">
              Update Consignment Tracking: {updatingShipmentAWB}
            </h4>

            <form onSubmit={handleUpdateStatusSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">New Stage Status</label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  <option value="Booked">Booked & Barcode Created</option>
                  <option value="In Transit">In Transit / Flight Departure</option>
                  <option value="Customs Clearance">Customs Clearance Processing</option>
                  <option value="Out for Delivery">Out for Doorstep Delivery</option>
                  <option value="Delivered">Delivered with Signature (Completed)</option>
                  <option value="On Hold">On Hold / Awaiting Documents</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Checkpoint Location</label>
                <input
                  type="text"
                  placeholder="e.g. Chicago O'Hare International Hub (ORD)"
                  value={newCheckpointLocation}
                  onChange={(e) => setNewCheckpointLocation(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Checkpoint Milestone Description</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Inbound customs inspection approved, dispatched on local delivery van."
                  value={newCheckpointDesc}
                  onChange={(e) => setNewCheckpointDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setUpdatingShipmentAWB(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold hover:bg-slate-100 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition shadow-md cursor-pointer"
                >
                  Save & Broadcast Live Tracking
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add New Country Tariff Modal */}
      {showAddCountryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-200">
            <h4 className="font-black text-slate-900 text-base">
              Add New International Country Tariff
            </h4>

            <form onSubmit={handleAddNewCountry} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Country Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Italy or Sweden"
                  value={newCountryName}
                  onChange={(e) => setNewCountryName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Country Code (2-Letter)</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. IT"
                    value={newCountryCode}
                    onChange={(e) => setNewCountryCode(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium text-slate-900 uppercase"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Flag Emoji</label>
                  <input
                    type="text"
                    placeholder="🇮🇹"
                    value={newCountryFlag}
                    onChange={(e) => setNewCountryFlag(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Public Rate/kg (₹)</label>
                  <input
                    type="number"
                    required
                    value={newCountryBaseRate}
                    onChange={(e) => setNewCountryBaseRate(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Agent Wholesale/kg (₹)</label>
                  <input
                    type="number"
                    required
                    value={newCountryWholesaleRate}
                    onChange={(e) => setNewCountryWholesaleRate(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-blue-50 border border-blue-300 rounded-xl font-bold text-blue-900"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddCountryModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold hover:bg-slate-100 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition shadow-md cursor-pointer"
                >
                  Add Tariff
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
