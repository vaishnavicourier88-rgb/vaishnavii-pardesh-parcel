import React from 'react';
import { Printer, X, ShieldCheck, Plane, QrCode, FileText, CheckCircle2 } from 'lucide-react';
import { ShipmentData } from '../../types';

interface AWBLabelPrintModalProps {
  shipment: ShipmentData | null;
  onClose: () => void;
}

export const AWBLabelPrintModal: React.FC<AWBLabelPrintModalProps> = ({ shipment, onClose }) => {
  if (!shipment) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-300 overflow-hidden relative my-6">
        
        {/* Modal Controls Top Bar (Hidden on print) */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-400" />
            <span className="font-bold text-sm">International Consignment Airway Bill (AWB)</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-md transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print AWB Label</span>
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Label Layout */}
        <div id="printable-awb-area" className="p-6 sm:p-8 bg-white text-slate-900 font-sans border border-slate-200">
          
          {/* Header with Logo & Airway Bill Number */}
          <div className="flex items-start justify-between border-b-2 border-slate-900 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-tight text-slate-900">
                  VAISHNAVII
                </span>
                <span className="text-[10px] uppercase font-bold bg-blue-700 text-white px-1.5 py-0.5 rounded">
                  INTERNATIONAL
                </span>
              </div>
              <p className="text-[11px] text-slate-600 font-semibold mt-0.5">
                Worldwide Express Courier & Cargo Clearance
              </p>
              <p className="text-[10px] text-slate-500">
                Email: vaishnavicourier88@gmail.com | Helpline: +91 98200 12345
              </p>
            </div>

            <div className="text-right">
              <span className="text-[10px] font-mono uppercase text-slate-500 font-bold block">
                PRIORITY AIRWAY BILL NO.
              </span>
              <span className="text-lg font-black font-mono tracking-wider text-blue-900 bg-blue-50 px-2.5 py-1 rounded-md border border-blue-200 inline-block mt-0.5">
                {shipment.trackingNumber}
              </span>
            </div>
          </div>

          {/* Barcode Mock Visual */}
          <div className="my-4 p-3 bg-slate-50 border border-slate-200 rounded-xl flex flex-col items-center justify-center">
            {/* Visual SVG Barcode bars */}
            <div className="flex items-center gap-[2px] h-12 w-full max-w-sm justify-center py-1">
              {[3,1,2,4,1,3,2,1,4,2,3,1,2,4,3,1,2,3,4,1,2,3,1,4,2,3,1,2,4,1,3,2,4,1,3].map((w, i) => (
                <div 
                  key={i} 
                  className="bg-slate-900 h-full" 
                  style={{ width: `${w * 2.5}px` }} 
                />
              ))}
            </div>
            <span className="font-mono text-xs font-bold tracking-widest text-slate-700 mt-1">
              *{shipment.trackingNumber}*
            </span>
          </div>

          {/* Sender & Receiver Address Grid */}
          <div className="grid grid-cols-2 gap-4 border-2 border-slate-900 rounded-xl overflow-hidden mb-4">
            
            {/* Sender Box */}
            <div className="p-3.5 bg-slate-50/70 border-r-2 border-slate-900">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1">
                <span>FROM / SHIPPER (ORIGIN)</span>
              </div>
              <div className="font-black text-sm text-slate-900">{shipment.senderName}</div>
              <div className="text-xs text-slate-700 mt-0.5 font-medium">
                {shipment.senderAddress || `${shipment.senderCity}, India`}
              </div>
              <div className="text-xs text-slate-900 font-bold mt-1">
                City: {shipment.senderCity}, {shipment.senderCountry}
              </div>
              <div className="text-xs text-slate-600 mt-0.5 font-mono">
                Phone: {shipment.senderPhone || '+91 98200 XXXXX'}
              </div>
            </div>

            {/* Receiver Box */}
            <div className="p-3.5 bg-blue-50/50">
              <div className="text-[10px] font-bold uppercase tracking-wider text-blue-700 mb-1 flex items-center gap-1">
                <span>TO / CONSIGNEE (DESTINATION)</span>
              </div>
              <div className="font-black text-sm text-slate-900">{shipment.receiverName}</div>
              <div className="text-xs text-slate-700 mt-0.5 font-medium">
                {shipment.receiverAddress || `${shipment.receiverCity}, ${shipment.receiverCountry}`}
              </div>
              <div className="text-xs text-slate-900 font-bold mt-1">
                {shipment.receiverCity}, {shipment.receiverCountry}
              </div>
              <div className="text-xs text-slate-600 mt-0.5 font-mono">
                Postal Code: {shipment.receiverPostalCode || 'ZIP-N/A'} | Phone: {shipment.receiverPhone || 'Verified'}
              </div>
            </div>
          </div>

          {/* Shipment Parameters Table */}
          <div className="grid grid-cols-4 gap-2 text-center text-xs mb-4">
            <div className="p-2.5 bg-slate-100 rounded-lg border border-slate-200">
              <span className="text-[10px] text-slate-500 block uppercase font-semibold">Service Type</span>
              <span className="font-bold text-slate-900 text-xs">{shipment.serviceType}</span>
            </div>
            <div className="p-2.5 bg-slate-100 rounded-lg border border-slate-200">
              <span className="text-[10px] text-slate-500 block uppercase font-semibold">Actual / Chg Weight</span>
              <span className="font-bold text-blue-800 text-xs">{shipment.weightKg} KG</span>
            </div>
            <div className="p-2.5 bg-slate-100 rounded-lg border border-slate-200">
              <span className="text-[10px] text-slate-500 block uppercase font-semibold">Network Routing</span>
              <span className="font-bold text-slate-900 text-xs">{shipment.partnerNetwork}</span>
            </div>
            <div className="p-2.5 bg-slate-100 rounded-lg border border-slate-200">
              <span className="text-[10px] text-slate-500 block uppercase font-semibold">Pieces / Boxes</span>
              <span className="font-bold text-slate-900 text-xs">{shipment.pieces} PKG</span>
            </div>
          </div>

          {/* Commodity & Customs Declaration */}
          <div className="border border-slate-300 rounded-xl p-3 bg-slate-50/50 mb-4 text-xs">
            <div className="text-[10px] font-bold uppercase text-slate-600 mb-1">
              Contents & Customs Declaration:
            </div>
            <p className="text-slate-800 font-semibold">
              {shipment.packageType || 'Non-commercial gift parcel containing verified permitted consumer items.'}
            </p>
            <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2 pt-2 border-t border-slate-200">
              <span>Declared Customs Value: ₹{shipment.declaredValueInr || (shipment.weightKg * 900)} INR</span>
              <span>Payment Status: <strong className="text-emerald-700">{shipment.paymentStatus || 'Paid'}</strong></span>
              <span>Origin Hub: <strong>{shipment.originAirport.substring(0, 3)}</strong></span>
            </div>
          </div>

          {/* Signatures & Security Stamp */}
          <div className="grid grid-cols-2 gap-6 pt-3 border-t-2 border-slate-300 text-[11px]">
            <div>
              <span className="font-semibold text-slate-600 block mb-6">Shipper / Agent Signature:</span>
              <div className="border-b border-dashed border-slate-400 w-48"></div>
              <span className="text-[10px] text-slate-500 mt-1 block">Booked by: {shipment.bookedBy || 'Vaishnavii Cargo Desk'}</span>
            </div>

            <div className="text-right">
              <span className="font-semibold text-slate-600 block mb-6">Customs & IATA Inspection Stamp:</span>
              <div className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-md font-mono text-[10px] font-bold uppercase">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>EXPORT CLEARED • BOM/DEL CARGO</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
