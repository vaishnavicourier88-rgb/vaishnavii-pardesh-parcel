import { CountryRate, PickupBookingRequest, ShipmentData, StaffUser, UserRole } from '../types';
import { DEFAULT_STAFF_USERS, MOCK_PICKUP_LEADS, MOCK_SHIPMENTS, POPULAR_COUNTRIES } from '../data/mockData';

const STORAGE_KEYS = {
  STAFF_USERS: 'vic_staff_users_v1',
  AUTH_SESSION: 'vic_auth_session_v1',
  COUNTRY_RATES: 'vic_country_rates_v1',
  SHIPMENTS: 'vic_shipments_v1',
  PICKUP_LEADS: 'vic_pickup_leads_v1',
};

export interface AuthSession {
  user: StaffUser;
  token: string;
  loginTime: string;
}

// 1. Get/Set Staff Users
export function getStaffUsers(): (StaffUser & { passwordHash: string })[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.STAFF_USERS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.STAFF_USERS, JSON.stringify(DEFAULT_STAFF_USERS));
      return DEFAULT_STAFF_USERS;
    }
    return JSON.parse(data);
  } catch (e) {
    console.error('Failed to load staff users', e);
    return DEFAULT_STAFF_USERS;
  }
}

export function saveStaffUsers(users: (StaffUser & { passwordHash: string })[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.STAFF_USERS, JSON.stringify(users));
  } catch (e) {
    console.error('Failed to save staff users', e);
  }
}

// 2. Auth Session Management
export function getAuthSession(): AuthSession | null {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.AUTH_SESSION);
    if (!data) return null;
    return JSON.parse(data);
  } catch (e) {
    return null;
  }
}

export function setAuthSession(session: AuthSession | null): void {
  if (!session) {
    localStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
  } else {
    localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, JSON.stringify(session));
  }
}

export function clearAuthSession(): void {
  localStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
}

// 3. Country Tariff & Rates Management
export function getCountryRates(): CountryRate[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.COUNTRY_RATES);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.COUNTRY_RATES, JSON.stringify(POPULAR_COUNTRIES));
      return POPULAR_COUNTRIES;
    }
    return JSON.parse(data);
  } catch (e) {
    console.error('Failed to load country rates', e);
    return POPULAR_COUNTRIES;
  }
}

export function saveCountryRates(rates: CountryRate[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.COUNTRY_RATES, JSON.stringify(rates));
  } catch (e) {
    console.error('Failed to save country rates', e);
  }
}

// 4. Shipments / AWB Consignments Management
export function getShipments(): Record<string, ShipmentData> {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SHIPMENTS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.SHIPMENTS, JSON.stringify(MOCK_SHIPMENTS));
      return MOCK_SHIPMENTS;
    }
    return JSON.parse(data);
  } catch (e) {
    console.error('Failed to load shipments', e);
    return MOCK_SHIPMENTS;
  }
}

export function saveShipments(shipments: Record<string, ShipmentData>): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SHIPMENTS, JSON.stringify(shipments));
  } catch (e) {
    console.error('Failed to save shipments', e);
  }
}

export function addOrUpdateShipment(shipment: ShipmentData): void {
  const current = getShipments();
  current[shipment.trackingNumber] = shipment;
  saveShipments(current);
}

// 5. Pickup Leads Management
export function getPickupLeads(): PickupBookingRequest[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.PICKUP_LEADS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.PICKUP_LEADS, JSON.stringify(MOCK_PICKUP_LEADS));
      return MOCK_PICKUP_LEADS;
    }
    return JSON.parse(data);
  } catch (e) {
    console.error('Failed to load pickup leads', e);
    return MOCK_PICKUP_LEADS;
  }
}

export function savePickupLeads(leads: PickupBookingRequest[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.PICKUP_LEADS, JSON.stringify(leads));
  } catch (e) {
    console.error('Failed to save pickup leads', e);
  }
}

export function addPickupLead(lead: PickupBookingRequest): void {
  const current = getPickupLeads();
  const newLead: PickupBookingRequest = {
    ...lead,
    id: lead.id || `lead_${Date.now()}`,
    status: lead.status || 'Pending',
    createdAt: lead.createdAt || new Date().toISOString().replace('T', ' ').substring(0, 16),
  };
  savePickupLeads([newLead, ...current]);
}

// 6. Generate Unique Airway Bill (AWB) number
export function generateNextAWB(): string {
  const randomDigits = Math.floor(10000 + Math.random() * 90000);
  return `VIC-${randomDigits}IN`;
}
